import React from 'react';
import { StyleSheet, Text, Image, View } from 'react-native';

const PoubelleVerte = () => {
  
  return (
    <View style={styles.container}>
      <Image
        source={require('./public/img/pv.png')}
        style={styles.image}
     />
    </View>
  );

}

const styles = StyleSheet.create({
container :{
  flex : 1,
  width : '100%',
  justifyContent : 'center',
  alignContent : 'center',
  alignItems : 'center',
  backgroundColor : '#333333',
},
image: {
  
  resizeMode: 'contain',
  width: '140%',
  height: undefined,
  aspectRatio: 1,
},
});



export default PoubelleVerte;