import React from 'react';
import {
  StyleSheet,
  View,
  useColorScheme,
  SafeAreaView,
  Text,
  TouchableOpacity,
  Image,
} from 'react-native';
import Header from './header';
import Footer from './footer';

const Accueil = ({navigation}) => {
  const isDarkMode = useColorScheme() === 'dark';
  const backgroundStyle = {
    backgroundColor: isDarkMode ? '#000000' : '#FFFFFF',
    flex: 1,
  };

  return (
    <SafeAreaView style={backgroundStyle}>
      <View style={styles.container}>
        <Header />
        <View style={backgroundStyle}>
          <View style={styles.content}>
            <Text style={styles.contentTitle}>
              ACTIVER LA GEOLOCALISATION EN CLIQUANT SUR LA CARTE
            </Text>
            <View style={styles.imageContainer}>
              <TouchableOpacity
                onPress={() => navigation.navigate('InfoGenerales')}>
                <Image
                  source={require('./public/img/dechetgo-logo.png')}
                  style={styles.image}
                />
              </TouchableOpacity>
            </View>
          </View>
        </View>
        <Footer />
      </View>
    </SafeAreaView>
  );
};

export default Accueil;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  gradientBar: {
    height: 4,
  },
  gradient: {
    flex: 1,
    flexDirection: 'row',
  },
  gradientColor: {
    flex: 1,
  },
  menu: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#333333',
    height: 30,
    paddingHorizontal: 20,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
    backgroundColor: '#333333',
  },
  contentTitle: {
    textAlign: 'center',
    fontSize: 14,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 5,
  },
  imageContainer: {
    flex: 1,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    flex: 1,
    resizeMode: 'contain',
    width: '120%',
    height: undefined,
    aspectRatio: 1,
  },
});
