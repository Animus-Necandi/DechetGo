import React from 'react';
import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';

const InfoGenerales = ({navigation}) => {
  
    return (
      <View style={styles.container}>
        <View style={styles.textContainer}>
          <Text style={styles.text}>Poubelle bleue</Text>
          <TouchableOpacity onPress={() => navigation.navigate('PoubelleBleue')}>
            <Text style={styles.detail}>Détail</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.textContainer}>
          <Text style={styles.text}>Poubelle verte</Text>
          <TouchableOpacity onPress={() => navigation.navigate('PoubelleVerte')}>
            <Text style={styles.detail}>Détail</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.textContainer}>
          <Text style={styles.text}>Poubelle jaune</Text>
          <TouchableOpacity onPress={() => navigation.navigate('PoubelleJaune')}>
            <Text style={styles.detail}>Détail</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Decheteries')}>
            <Text style={styles.buttonText}>Décheterie</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Collecte')}>
            <Text style={styles.buttonText}>Collecte des ordures ménagères</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#333333',
  },
  textContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: 30,
    marginVertical: 10,
  },
  text: {
    fontSize: 20,
    color: 'white',
  },
  detail: {
    fontSize: 18,
    color: 'rgba(255, 179, 71, 1)',
    marginLeft : 20,
    textDecorationLine: 'underline',
  },
  buttonContainer: {
    marginTop: 50,
  },
  button: {
    borderRadius: 20,
    padding: 10,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 179, 71, 1)',
    marginTop : 20,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 18,
  },
});

export default InfoGenerales;
