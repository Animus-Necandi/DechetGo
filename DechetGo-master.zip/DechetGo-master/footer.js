import React from 'react';
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  useColorScheme,
  View,
  Image,
} from 'react-native';

class Footer extends React.Component {
  render() {
    
    const gradientColors = ['#999999', '#777777', '#555555'];
    return (
      <View>
        <View style={styles.content2}>
          <Text style={styles.contentTitle2}>
            CETTE APP EST DEVELOPPÉE DANS LE CADRE DU TITRE DE CDA
          </Text>
        </View>
        <View style={styles.gradientBar}>
          <View style={styles.gradient}>
            <View
              style={[
                styles.gradientColor,
                {backgroundColor: gradientColors[0]},
              ]}
            />
            <View
              style={[
                styles.gradientColor,
                {backgroundColor: gradientColors[1]},
              ]}
            />
            <View
              style={[
                styles.gradientColor,
                {backgroundColor: gradientColors[2]},
              ]}
            />
          </View>
        </View>
      </View>
    );
  }
}

export default Footer;

const styles = StyleSheet.create({
  gradientBar: {
    height: 4,
  },
  gradient: {
    flex: 1,
    flexDirection: 'row',
  },
  gradientColor: {
    flex: 1,
  },
  content2: {    
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
    backgroundColor: '#333333',
    color: '#FFFFFF',
  },
  contentTitle2: {
    fontSize: 10,
    color: '#FFFFFF',
  },
});
