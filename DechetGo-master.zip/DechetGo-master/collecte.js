import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

const Collecte = () => {
  
    return (
      <View style={styles.container}>
        <Text style={styles.titre}>Horaire de votre collecte de déchets</Text>
        <View style={styles.table}>
          <View style={styles.row}>
            <View style={[styles.cell, styles.header]}>
              <Text style={styles.text}>Jour</Text>
            </View>
            <View style={[styles.cell, styles.header]}>
              <Text style={styles.text}>Horaire</Text>
            </View>
          </View>
          <View style={styles.row}>
            <View style={styles.cell}>
              <Text style={styles.text}>Lundi</Text>
            </View>
            <View style={styles.cell}>
              <Text style={styles.text}>Matin</Text>
              <Text style={styles.text}>Après-midi</Text>
            </View>
          </View>
          <View style={styles.row}>
            <View style={styles.cell}>
              <Text style={styles.text}>Mardi</Text>
            </View>
            <View style={styles.cell}>
              <Text style={styles.text}>Matin</Text>
              <Text style={styles.text}>Après-midi</Text>
            </View>
          </View>
          <View style={styles.row}>
            <View style={styles.cell}>
              <Text style={styles.text}>Mercredi</Text>
            </View>
            <View style={styles.cell}>
              <Text style={styles.text}>Matin</Text>
              <Text style={styles.text}>Après-midi</Text>
            </View>
          </View>
          <View style={styles.row}>
            <View style={styles.cell}>
              <Text style={styles.text}>Jeudi</Text>
            </View>
            <View style={styles.cell}>
              <Text style={styles.text}>Matin</Text>
              <Text style={styles.text}>Après-midi</Text>
            </View>
          </View>
          <View style={styles.row}>
            <View style={styles.cell}>
              <Text style={styles.text}>Vendredi</Text>
            </View>
            <View style={styles.cell}>
              <Text style={styles.text}>Matin</Text>
              <Text style={styles.text}>Après-midi</Text>
            </View>
          </View>
          <View style={styles.row}>
            <View style={styles.cell}>
              <Text style={styles.text}>Samedi</Text>
            </View>
            <View style={styles.cell}>
              <Text style={styles.text}>Matin</Text>
              <Text style={styles.text}>Après-midi</Text>
            </View>
          </View>
          <View style={styles.row}>
            <View style={styles.cell}>
              <Text style={styles.text}>Dimanche</Text>              
            </View>
            <View style={styles.cell}>
              <Text style={styles.text}>Matin</Text>
              <Text style={styles.text}>Après-midi</Text>
            </View>
          </View>
        </View>
      </View>
    );  
}

const styles = StyleSheet.create({
  container : {
    flex : 1,
    backgroundColor : '#333333',
    
  },
  titre : {
    color : '#ffffff',
    fontWeight : 'bold',
    textAlign :'center',
    marginTop : 20,
    marginBottom : 20,
  },
  table: {
    borderWidth: 1,
    borderColor: 'black',
  },
  row: {
    flexDirection: 'row',
  },
  cell: {
    flex: 1,
    borderWidth: 1,
    borderColor: 'black',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 5,    
  },
  header: {
    backgroundColor: 'lightgrey',
  },
  text  :{
    fontWeight : 'bold',
    color :'#000000'
  },
});

export default Collecte;
