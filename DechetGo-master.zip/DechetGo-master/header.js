import React from 'react';
import {
    SafeAreaView,
    ScrollView,
    StatusBar,
    StyleSheet,
    Text,
    useColorScheme,
    View,
    Image,
  } from 'react-native';

  

  
class Header extends React.Component {

    
  render() {
   
    
      const gradientColors = ['#999999', '#777777', '#555555'];
    return (
      
      <View>
      <View style={styles.gradientBar}>
        <View style={styles.gradient}>
          <View style={[styles.gradientColor, {backgroundColor: gradientColors[0]}]} />
          <View style={[styles.gradientColor, {backgroundColor: gradientColors[1]}]} />
          <View style={[styles.gradientColor, {backgroundColor: gradientColors[2]}]} />
        </View>
      </View>
      <View style={styles.menu}>
        <Text style={styles.menuTitle}>DechetGo</Text>
      </View>
    </View>
    );
  }
}


export default Header;

const styles = StyleSheet.create({
    gradientBar: {
      height: 4,
    },
    gradient: {
      flex: 1,
      flexDirection: 'row',
    },
    gradientColor: {
      flex: 1,
    },
    menu: {
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: '#333333',
      height: 30,
      paddingHorizontal: 20,
    },
    menuTitle: {
      color: '#FFFFFF',
      fontSize: 20,
      fontWeight: 'bold',
      
    },
    menuSeparator: { 
      height: 1,
      backgroundColor: '#CBCBD4',
    },
  });
  

  
  