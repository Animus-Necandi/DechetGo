import {AppRegistry} from 'react-native';
import {name as appName} from './app.json';
import {NavigationContainer} from '@react-navigation/native';


import * as React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';

import InfoGenerales from './infoGenerales';
import Accueil from './accueil';
import PoubelleBleue from './poubelleBleue';
import PoubelleJaune from './poubelleJaune';
import PoubelleVerte from './poubelleVerte';
import Decheteries from './decheteries';
import Collecte from './collecte';


const Stack = createNativeStackNavigator();

const MyStack = () => {
  return (

    
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen
          name="Accueil"
          component={Accueil}
          options={{title: 'Bienvenue'}}
        />
          <Stack.Screen
          name="InfoGenerales"
          component={InfoGenerales}
          options={{title: 'InfoGenerales'}}
        />
        <Stack.Screen
          name="PoubelleVerte"
          component={PoubelleVerte}
          options={{title: 'PoubelleVerte'}}
        />
        <Stack.Screen
          name="PoubelleJaune"
          component={PoubelleJaune}
          options={{title: 'PoubelleJaune'}}
        />
        <Stack.Screen
          name="PoubelleBleue"
          component={PoubelleBleue}
          options={{title: 'PoubelleBleue'}}
        />
        <Stack.Screen
          name="Decheteries"
          component={Decheteries}
          options={{title: 'Decheteries'}}
        />
        <Stack.Screen
          name="Collecte"
          component={Collecte}
          options={{title: 'Collecte'}}
        />
      
      </Stack.Navigator>
    </NavigationContainer>
  );
};

AppRegistry.registerComponent(appName, () => MyStack);
