/**
 * DechetGo App
 * https://github.com/example/dechetgo
 *
 * @format
 */

import React from 'react';
import {
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  useColorScheme,
  View,
  Image,
} from 'react-native';

// type MenuItemProps = {
//   title: string;
// };

// function MenuItem({title}: MenuItemProps): JSX.Element {
//   return (
//     <TouchableOpacity style={styles.menuItem}>
//       <Text style={styles.menuItemTitle}>{title}</Text>
//     </TouchableOpacity>
//   );
// }

function App(props : any): JSX.Element {
  const isDarkMode = useColorScheme() === 'dark';

  const backgroundStyle = {
    backgroundColor: isDarkMode ? '#000000' : '#FFFFFF',
    flex: 1,
  };

  const gradientColors = ['#999999', '#777777', '#555555'];

  return (
    <SafeAreaView style={backgroundStyle}>
      
     
      <ScrollView
        contentInsetAdjustmentBehavior="automatic"
        style={backgroundStyle}>
        <View style={styles.content}>
          <Text style={styles.contentTitle}>ACTIVER LA GEOLOCALISATION EN CLIQUANT SUR LA CARTE  App.tsx</Text>
          <View style={styles.imageContainer}>
              <TouchableOpacity onPress={() =>
            props.navigation.navigate('InfoGenerales')}>
                <Image
                  source={require('./public/img/dechetgo-logo.png')}
                  style={styles.image}
                />
              </TouchableOpacity>
            </View>

        </View>
        <View style={styles.content}>
          <Text style={styles.contentTitle2}>CETTE APP EST DEVELOPPÉE DANS LE CADRE DU TITRE DE CDA</Text>
        </View>
        <View style={styles.gradientBar}>
        <View style={styles.gradient}>
          <View style={[styles.gradientColor, {backgroundColor: gradientColors[0]}]} />
          <View style={[styles.gradientColor, {backgroundColor: gradientColors[1]}]} />
          <View style={[styles.gradientColor, {backgroundColor: gradientColors[2]}]} />
        </View>
      </View>
      </ScrollView>
    </SafeAreaView>
  );
}


const styles = StyleSheet.create({
  gradientBar: {
    height: 4,
  },
  gradient: {
    flex: 1,
    flexDirection: 'row',
  },
  gradientColor: {
    flex: 1,
  },
  menu: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#333333',
    height: 30,
    paddingHorizontal: 20,
  },
  menuTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    
  },
  menuSeparator: { 
    height: 1,
    backgroundColor: '#CBCBD4',
  },
  menuItem: {
    paddingHorizontal: 10,
  },
  menuItemTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 10,
    backgroundColor: '#333333',
  },
  contentTitle: {
    textAlign: 'center',
    fontSize: 14,
    fontWeight: 'bold',
    color: '#FFFFFF',
    marginBottom: 5,
    
  },
  contentTitle2: {
    fontSize: 10,
    color: '#FFFFFF'
    
  },
  imageContainer: {
    flex: 1,
    width: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  image: {
    flex: 1,
    resizeMode: 'contain',
    width: '120%',
    height: undefined,
    aspectRatio: 1,
  },
});

export default App;

